package com.ds.layer4_Services;

import java.util.List;

import com.ds.layer2_POJO.Advertisements;

public interface AdvertisementService {
	
     List<Advertisements> insertAdd = null;
	void saveAdvertisementService(Advertisements advertisement) throws AdvertisementsAlreadyExistsException;
     void modifyAdvertisementService(Advertisements advertisements) throws AdvertisementNotFoundException;
     Advertisements viewAdvertisementService(int addId);
     void removeAdvertisement(int addId);
	List<Advertisements> selectAllAdvertisements();
	  void editAdvertisementService(Advertisements advertisement) throws AdvertisementNotFoundException;

   


}

