package com.ds.layer4_Services;


import java.util.List;

import com.ds.layer2_POJO.Advertisements;
import com.ds.layer3_DAO.Advertisements.AdvertisementsDAO;
import com.ds.layer3_DAO.Advertisements.AdvertisementsDAOImpl;



public class AdvertisementServiceImpl implements AdvertisementService
{
    
	AdvertisementsDAO addDao = new AdvertisementsDAOImpl();
@Override
public void saveAdvertisementService(Advertisements advertisements) throws AdvertisementsAlreadyExistsException {
	// TODO Auto-generated method stub
	List<Advertisements> listAdvertisements = addDao.selectAllAdvertisements();
	boolean addFound=false;	
	for (Advertisements adds : listAdvertisements) {
		if(adds.getAddBrandName()== advertisements.getAddBrandName())  {
				addFound=true;	break;
		} 
	}

if(addFound==true)throw new AdvertisementsAlreadyExistsException();
else addDao.insertAdd(advertisements);
	
}


@Override
public void modifyAdvertisementService(Advertisements advertisements) throws AdvertisementNotFoundException {
	// TODO Auto-generated method stub
	List<Advertisements> listAdvertisements = addDao.selectAllAdvertisements();
	boolean addFound=false;	
	for (Advertisements adds : listAdvertisements) {
		if(adds.getAddId()== advertisements.getAddId())  {
				addFound=true;	
				break;
		} 
	}

if(addFound==false)
	{throw new AdvertisementNotFoundException();}
else 
	{addDao.updateAdd(advertisements);}
	
}



@Override
public void removeAdvertisement(int addId) {
	// TODO Auto-generated method stub
	List<Advertisements> listAdvertisements = addDao.selectAllAdvertisements();
	boolean addFound=false;	
	for (Advertisements adds : listAdvertisements) {
		if(adds.getAddId()== addId)  {
				addFound=true;	break;
		} 
	}

if(addFound==false);
else addDao.deleteAdd(addId);
	
}


@Override
public List<Advertisements> selectAllAdvertisements() {
	// TODO Auto-generated method stub
	return addDao.selectAllAdvertisements();
}


@Override
public Advertisements viewAdvertisementService(int addId) {
	
	return addDao.selectAdvertisement(addId);
}


@Override
public void editAdvertisementService(Advertisements advertisement) throws AdvertisementNotFoundException {
	// TODO Auto-generated method stub
	List<Advertisements> listAdvertisements = addDao.selectAllAdvertisements();
	boolean addFound=false;	
	for (Advertisements adds : listAdvertisements) {
		if(adds.getAddId()== advertisement.getAddId())  {
			addFound=true;	
				break;
		} 
	}

if(addFound==false)
	{throw new AdvertisementNotFoundException();}
else 
	{addDao.editAdd(advertisement);}
	
}



}