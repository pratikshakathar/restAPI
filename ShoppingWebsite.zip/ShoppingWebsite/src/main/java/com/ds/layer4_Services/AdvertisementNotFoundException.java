package com.ds.layer4_Services;

public class AdvertisementNotFoundException extends Exception {
public static void main(String[] args) {
	
	
}
}
