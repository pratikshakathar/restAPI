package com.ds.layer4_Services;

public class AdvertisementsAlreadyExistsException extends Exception {
 public static void main(String[] args) {
	
	 
}
}
