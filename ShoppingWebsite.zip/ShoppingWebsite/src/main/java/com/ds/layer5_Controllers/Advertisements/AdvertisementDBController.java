package com.ds.layer5_Controllers.Advertisements;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.ds.layer2_POJO.Advertisements;
import com.ds.layer4_Services.AdvertisementNotFoundException;
import com.ds.layer4_Services.AdvertisementService;
import com.ds.layer4_Services.AdvertisementServiceImpl;
import com.ds.layer4_Services.AdvertisementsAlreadyExistsException;


@Path("/advertisementdb") 
public class AdvertisementDBController {

	AdvertisementService advertisementservice = new AdvertisementServiceImpl();
	
	public AdvertisementDBController() {
		System.out.println("Advertisement controller called...");
	}
	
	
	
		//get all the details from the list
			@GET
			@Path("/get")
			@Produces(MediaType.APPLICATION_JSON)
		   public  Response getAdvertisements(){
			 
			  return Response
						.status(Response.Status.OK)
						.entity(advertisementservice.selectAllAdvertisements())
						.build();
		   }
				

	
	@POST 
	@Path("/add")
	public Response addIt(Advertisements addObj) {
		
		try {
			
			advertisementservice.saveAdvertisementService(addObj);
			
			 return Response
						.status(Response.Status.OK)
						.entity("record added successfully")
						.build();

		} catch (AdvertisementsAlreadyExistsException e) {
			return Response
			.status(Response.Status.NOT_FOUND)
			.entity(e.getMessage())
			.build();
		}
	}
	
	@PUT 
	@Path("/edit")
	public Response modifyIt(Advertisements addObj) {
		
		try {
			advertisementservice.modifyAdvertisementService(addObj);
			return Response
					.status(Response.Status.OK)
					.entity("record modified successfully")
					.build();

		} catch (AdvertisementNotFoundException e) {
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(e.getMessage())
					.build();
		}
	}
	
	
	@DELETE
	@Path("/delete/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteIt(@PathParam("cid")int x) {
		advertisementservice.removeAdvertisement(x );
		return Response
				.status(Response.Status.OK)
				.entity("record Deleted successfully")
				.build();
	
	}
	
	@GET 
	@Path("/getadd/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Advertisements getIt(@PathParam("cid")int x) {
		
		
			
			return advertisementservice.viewAdvertisementService(x);

		
	}
	@PUT 
	@Path("/editall")
	@Produces(MediaType.APPLICATION_JSON)
	public Response editIt(Advertisements addObj) {
		
		try {
			advertisementservice.editAdvertisementService(addObj);
			return Response
					.status(Response.Status.OK)
					.entity("record edited successfully")
					.build();

		} catch (AdvertisementNotFoundException e) {
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(e.getMessage())
					.build();
		}
	}
}
