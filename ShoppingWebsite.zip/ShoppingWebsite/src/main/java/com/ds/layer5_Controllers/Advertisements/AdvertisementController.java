package com.ds.layer5_Controllers.Advertisements;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Path;

import com.ds.layer2_POJO.Advertisements;

/*

@Path("/add") 
public class AdvertisementController {
	static List<Advertisements> addList = new ArrayList<Advertisements>();
	{
		Advertisements add1 = new Advertisements();
		add1.setAddId(1);
		add1.setAddBrandName("PUMA");
		add1.setAddDiscount("50%");
		add1.setAddImageUrl("https://cdn.zouton.com/images/originals/stores/overviewsArtboard_3_2_1611547666.png");
		add1.setAddStartDate(LocalDate.of(2023,03,12));
		
		add1.setAddEndDate(LocalDate.of(2023, 03, 15));
		
		Advertisements add2 = new Advertisements();
		add2.setAddId(2);
		add2.setAddBrandName("BOAT");
		add2.setAddDiscount("70%");
		add2.setAddImageUrl("https://th.bing.com/th/id/OIP.EB7BoKmXUrwvFEXtQE8XUAHaC0?pid=ImgDet&rs=1");
        add2.setAddStartDate(LocalDate.of(2023,03,12));
		add2.setAddEndDate(LocalDate.of(2023, 03, 15));
		
		Advertisements add3 = new Advertisements();
		add3.setAddId(1);
		add3.setAddBrandName("VIVO");
		add3.setAddDiscount("50%");
		add3.setAddImageUrl("https://www.swirlingovercoffee.com/wp-content/uploads/2019/03/Shopee-ViVo-Sale.jpg");
        add3.setAddStartDate(LocalDate.of(2023,03,12));
		add3.setAddEndDate(LocalDate.of(2023, 03, 15));
	}
		
		
		
		
		
		
	}
*/
