package com.ds.layer3_DAO.Advertisements;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.ds.layer2_POJO.Advertisements;


public class AdvertisementsDAOImpl implements AdvertisementsDAO {
	
	Connection conn;
	public AdvertisementsDAOImpl() {
		try {
			
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			this.conn = DriverManager.getConnection("jdbc:mysql://10.94.12.33/mysql", "root", "root");
			
		} catch (SQLException e) {e.printStackTrace();}
}
	
	/*
	*/
	
	
	

	@Override
	public Advertisements selectAdvertisement(int addId) {
		// TODO Auto-generated method stub
		Advertisements advertisement = null;
		try {
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT * FROM Advertisements where addId="+addId); 
			

			if (result.next()) {
				advertisement = new Advertisements();
				advertisement.setAddId(result.getInt(1)); //fill it up column wise
				advertisement.setAddBrandName(result.getString(2));
				advertisement.setAddDiscount(result.getString(3));
				advertisement.setAddImageUrl(result.getString(4));
				advertisement.setAddEndDate(result.getDate(5));
				advertisement.setAddEndDate(result.getDate(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return advertisement;
	
	}

	@Override
	public List<Advertisements> selectAllAdvertisements() {
		// TODO Auto-generated method stub
		List<Advertisements> addList = new ArrayList<Advertisements>();
		try {
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT * FROM advertisements");
			
			while (result.next()) {
				Advertisements advertisement = new Advertisements();
				advertisement.setAddId(result.getInt(1)); 
				advertisement.setAddStatus(result.getString(2));
				advertisement.setAddBrandName(result.getString(3));
				advertisement.setAddDiscount(result.getString(4));
				advertisement.setAddImageUrl(result.getString(5));
				advertisement.setAddStartDate(result.getDate(6));
				advertisement.setAddEndDate(result.getDate(7));
				addList.add(advertisement);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return addList;
			
	}
	
	@Override
	public void insertAdd(Advertisements advertisement) {
	
		System.out.println(advertisement);
		try {
		PreparedStatement pst = conn.prepareStatement("insert into advertisements(addBrandName,addDiscount,addImageUrl,addStartDate,addEndDate) values(?,?,?,?,?)");
		pst.setString(1, advertisement.getAddBrandName());
		pst.setString(2, advertisement.getAddDiscount());
		
		pst.setString(3, advertisement.getAddImageUrl());
		pst.setDate(4,  advertisement.getAddStartDate());
		pst.setDate(5, advertisement.getAddEndDate());
		
		

		int rows = pst.executeUpdate(); 
	
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}
	
	
	
	
	 

	@Override
	public void updateAdd(Advertisements advertisement) {
		// TODO Auto-generated method stub
		System.out.println(advertisement);
		try {
			//PreparedStatement pst = conn.prepareStatement("UPDATE Advertisements set addStatus=?, addBrandName=?, addDiscount=?, addImageUrl=?, addStartDate=?, addEndDate=? where addId=?");
			PreparedStatement pst = conn.prepareStatement("UPDATE Advertisements set addStatus=? where addId=?");
			pst.setString(1, advertisement.getAddStatus());
			pst.setInt(2, advertisement.getAddId());
			
			/*
			 * pst.setString(1, advertisement.getAddStatus()); pst.setString(2,
			 * advertisement.getAddBrandName()); pst.setString(3,
			 * advertisement.getAddDiscount());
			 * 
			 * pst.setString(4, advertisement.getAddImageUrl()); pst.setDate(5,
			 * advertisement.getAddStartDate()); pst.setDate(6,
			 * advertisement.getAddEndDate());
			 * 
			 * 
			 * pst.setInt(7, advertisement.getAddId());
			 */


			int rows = pst.executeUpdate(); 
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	
	

	@Override
	public void deleteAdd(int addId) {
		// TODO Auto-generated method stub
		System.out.println(addId);
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM Advertisements  where addId=?");
			

			pst.setInt(1, addId);
			
			int rows = pst.executeUpdate();
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void editAdd(Advertisements advertisement) {
	System.out.println(advertisement);
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE Advertisements set  addBrandName=?, addDiscount=?, addImageUrl=?, addStartDate=?, addEndDate=? where addId=?");
		//	pst.setString(1, advertisement.getAddStatus());
			pst.setString(1,advertisement.getAddBrandName()); 
			pst.setString(2,advertisement.getAddDiscount());
			pst.setString(3, advertisement.getAddImageUrl());
			pst.setDate(4, advertisement.getAddStartDate());  
			pst.setDate(5,  advertisement.getAddEndDate());		
			 pst.setInt(6, advertisement.getAddId());		  
					
			 int rows = pst.executeUpdate(); 
				
				
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();		  			  
					
	}

}
}
