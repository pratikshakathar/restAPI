package com.ds.layer3_DAO.Advertisements;

import java.util.List;

import com.ds.layer2_POJO.Advertisements;

public interface AdvertisementsDAO {

	Advertisements selectAdvertisement(int addId);
	List<Advertisements> selectAllAdvertisements();
	
	void insertAdd(Advertisements advertisement);
	void updateAdd(Advertisements advertisement);
	void deleteAdd(int addId);
	void editAdd(Advertisements advertisement);
	
	
	
}