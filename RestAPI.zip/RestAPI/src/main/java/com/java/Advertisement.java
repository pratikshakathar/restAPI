package com.java;

public class Advertisement {
   private int addId;
   private String addHeadline;
   private int discAmt;
   private String productName;
   private String Deadline;
   private String URL;
   
public String getAddHeadline() {
	return addHeadline;
}
public void setAddHeadline(String addHeadline) {
	this.addHeadline = addHeadline;
}
public int getDiscAmt() {
	return discAmt;
}
public void setDiscAmt(int discAmt) {
	this.discAmt = discAmt;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getURL() {
	return URL;
}
public void setURL(String uRL) {
	URL = uRL;
}
public String getDeadline() {
	return Deadline;
}
public void setDeadline(String deadline) {
	Deadline = deadline;
}
public int getAddId() {
	return addId;
}
public void setAddId(int addId) {
	this.addId = addId;
}

   

   
  
}