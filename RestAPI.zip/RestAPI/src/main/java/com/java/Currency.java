package com.java;

public class Currency {
	private int currentId;
	private String Sourcecurrency;
	private String targetcurrency;
	private float amounttoconvert;
	
	public int getCurrentId() {
	return currentId;
	}
	public void setCurrentId(int currentId) {
	this.currentId = currentId;
	}
	public String getSourcecurrency() {
	return Sourcecurrency;
	}
	public void setSourcecurrency(String sourcecurrency) {
	this.Sourcecurrency = sourcecurrency;
	}
	public String getTargetcurrency() {
	return targetcurrency;
	}
	public void setTargetcurrency(String targetcurrency) {
	this.targetcurrency = targetcurrency;
	}
	public float getAmounttoconvert() {
	return amounttoconvert;
	}
	public void setAmounttoconvert(float amounttoconvert) {
	this.amounttoconvert = amounttoconvert;
	}
	}

