package com.java;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



@Path("/advertisement")
public class Add {
	static List<Advertisement> addList = new ArrayList<Advertisement>();
  static { 
	  Advertisement add1 = new Advertisement();
	    add1.setAddId(1);
    	add1.setAddHeadline("Big Saving Days");
    	add1.setDiscAmt(50 );
        add1.setProductName("BOAT Headphones");
    	add1.setDeadline("11th to 15th March");
    	add1.setURL("https://i.pinimg.com/originals/72/5d/7e/725d7e7056cbf4275425ba826e761fb8.jpg");


    	Advertisement add2 = new Advertisement();
    	add2.setAddId(2);
    	add2.setAddHeadline("Big Billion Days");
    	add2.setDiscAmt(60 );
        add2.setProductName("Fire bolt Smartwatch brand");
    	add2.setDeadline("29th sept to 4th oct");
    	add2.setURL("https://blebur.com/wp-content/uploads/2021/05/Flipkart-BigBillionDays2019-banner.jpg");

    	Advertisement add3 = new Advertisement();
    	add3.setAddId(3);
    	add3.setAddHeadline("Gudipadwa sale");
    	add3.setDiscAmt(40 );
        add3.setProductName("KItchen appliances");
    	add3.setDeadline("21st march to 26th march");
    	add3.setURL("https://s3-ap-southeast-1.amazonaws.com/s3.loopme.my/img/newos/posts/d/7532_I6NRUaieBPP8NrDi_.jpg");

    	
    	addList.add(add1);
    	addList.add(add2);
    	addList.add(add3);
  }
  public Add() {
  	System.out.println("Add called");
    }


@GET
@Path("/greet")
public String welcome() {
	
	return "<h1> Welcome to Shopping sites  </h1>";
}
@GET
@Path("/convert/{add}")
@Produces(MediaType.APPLICATION_JSON)
public Advertisement convertIt(@PathParam("add")int x) {
	
	Advertisement add1 = null;
	for(Advertisement advertisement : addList) {
		if(advertisement.getAddId()==x) {
			add1 =advertisement;
		}
	}
	return add1;
}


@DELETE
@Path("/delete/{add}")
@Produces(MediaType.APPLICATION_JSON)
public String deleteIt(@PathParam("add")int x) {
	boolean found=false;
	Advertisement add1 = null;
	for(Advertisement advertisement : addList) {
			if(advertisement.getAddId()==x) {
			add1 =advertisement;
			addList.remove(add1);
			found=true;
			break;
		}
	}
	if(found==true) 
		return "Advertisement Deleted";
	else 
		return "Advertisement not found";
	
}

@POST
@Path("/add")
@Produces(MediaType.APPLICATION_JSON)
public String addIt(Advertisement ADDobj) {
	boolean found=false;
    Advertisement add = null;
	for(Advertisement advertisement : addList) {
		if(advertisement.getAddId()==ADDobj.getAddId()) {
			
			found=true;
			break;
		}
	}
	if(found==true) 
		return "Advertisement already exists";
	else {
		addList.add(ADDobj);
	
		return "Advertisement added";
	
	}
}

@PUT
@Path("/update_add")
public String modifyIt(Advertisement ADDobj) {
	boolean found=false;
	Advertisement add = null;
	for(Advertisement advertisement : addList) {
		if(advertisement.getAddId()==ADDobj.getAddId()) {
			
			found=true;
			addList.remove(advertisement);
			break;
		}
	}
	if(found==true) 
	{
		addList.add(ADDobj);
	
		return "Advertisement modified";
	}
	else {
	
		return "Advertisement not found";
	
	}
}



@GET
@Path("/display_add")
@Produces(MediaType.APPLICATION_JSON)
public List<Advertisement>convertAll(){
	return addList;
}


}